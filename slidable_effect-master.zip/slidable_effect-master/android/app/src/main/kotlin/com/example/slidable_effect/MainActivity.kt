package com.example.slidable_effect

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
